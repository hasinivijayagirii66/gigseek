import os
from flask import Flask, render_template, redirect, url_for, request, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_bcrypt import Bcrypt
from werkzeug.utils import secure_filename
from sqlalchemy import or_

# Import our models (assuming they are in models.py)
from models import db, User, Gig, Application

app = Flask(__name__)

# --- Configuration ---
app.config['SECRET_KEY'] = 'super-secret-gigseek-key-2026'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///gigseek.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads/resumes'
app.config['ALLOWED_EXTENSIONS'] = {'pdf'}

# Create upload folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# --- Initialize Extensions ---
db.init_app(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# --- Routes: Authentication ---

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register/<role>', methods=['GET', 'POST'])
def register(role):
    if request.method == 'POST':
        hashed_password = bcrypt.generate_password_hash(request.form.get('password')).decode('utf-8')
        
        # Handle Resume Upload for Gigsters
        resume_filename = None
        if role == 'gigster' and 'resume' in request.files:
            file = request.files['resume']
            if file and allowed_file(file.filename):
                resume_filename = secure_filename(f"{request.form.get('email')}_resume.pdf")
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], resume_filename))

        new_user = User(
            name=request.form.get('name'),
            email=request.form.get('email'),
            password_hash=hashed_password,
            role=role,
            mobile=request.form.get('mobile'),
            portfolio=request.form.get('portfolio'),
            resume=resume_filename
        )
        
        try:
            db.session.add(new_user)
            db.session.commit()
            flash(f'Account created for {new_user.name}! You can now login.', 'success')
            return redirect(url_for('login'))
        except:
            flash('Email already exists.', 'danger')
            
    return render_template(f'register_{role}.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(email=request.form.get('email')).first()
        if user and bcrypt.check_password_hash(user.password_hash, request.form.get('password')):
            login_user(user)
            flash(f'Welcome back, {user.name}!', 'success')
            return redirect(url_for('dashboard'))
        flash('Login Unsuccessful. Please check email and password', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index'))

# --- Routes: Dashboard & Matching ---

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'host':
        my_gigs = Gig.query.filter_by(host_id=current_user.id).all()
        # Notification logic: count pending apps for all host's gigs
        pending_apps = Application.query.join(Gig).filter(
            Gig.host_id == current_user.id, 
            Application.status == 'Pending'
        ).count()
        return render_template('dashboard.html', gigs=my_gigs, pending_notifications=pending_apps)
    
    elif current_user.role == 'gigster':
        my_apps = Application.query.filter_by(user_id=current_user.id).all()
        return render_template('dashboard.html', applications=my_apps)
    
    return redirect(url_for('admin_panel'))

@app.route('/gig_feed')
@login_required
def gig_feed():
    if current_user.role != 'gigster':
        return redirect(url_for('dashboard'))
    
    search = request.args.get('search', '')
    location = request.args.get('location', '')
    
    query = Gig.query
    if search:
        query = query.filter(or_(Gig.title.contains(search), Gig.description.contains(search)))
    if location:
        query = query.filter(Gig.location.contains(location))
        
    gigs = query.order_by(Gig.created_at.desc()).all()
    return render_template('gig_feed.html', gigs=gigs)

@app.route('/post_gig', methods=['GET', 'POST'])
@login_required
def post_gig():
    if current_user.role != 'host':
        flash('Unauthorized access.', 'danger')
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        new_gig = Gig(
            title=request.form.get('title'),
            description=request.form.get('description'),
            salary=request.form.get('salary'),
            location=request.form.get('location'),
            host_id=current_user.id
        )
        db.session.add(new_gig)
        db.session.commit()
        flash('Gig posted successfully!', 'success')
        return redirect(url_for('dashboard'))
    return render_template('post_gig.html')

@app.route('/apply/<int:gig_id>', methods=['POST'])
@login_required
def apply(gig_id):
    if current_user.role != 'gigster':
        flash('Hosts cannot apply for gigs.', 'danger')
        return redirect(url_for('gig_feed'))
    
    existing_app = Application.query.filter_by(user_id=current_user.id, gig_id=gig_id).first()
    if existing_app:
        flash('You have already applied for this gig.', 'warning')
        return redirect(url_for('dashboard'))

    new_app = Application(gig_id=gig_id, user_id=current_user.id)
    db.session.add(new_app)
    db.session.commit()
    flash('Application sent! The host has been notified.', 'success')
    return redirect(url_for('dashboard'))

@app.route('/update_status/<int:app_id>/<status>')
@login_required
def update_status(app_id, status):
    application = Application.query.get_or_404(app_id)
    # Security: Ensure only the host who posted the gig can change status
    if application.gig.host_id != current_user.id:
        flash('Unauthorized action.', 'danger')
        return redirect(url_for('dashboard'))
    
    application.status = status
    db.session.commit()
    
    msg = "Match confirmed! Contact details revealed." if status == 'Accepted' else "Application updated."
    flash(msg, 'success')
    return redirect(url_for('dashboard'))

# --- Admin Management ---

@app.route('/admin')
@login_required
def admin_panel():
    if current_user.role != 'admin':
        return redirect(url_for('index'))
    users = User.query.all()
    gigs = Gig.query.all()
    return render_template('admin.html', users=users, gigs=gigs)

# --- Database Initialization ---
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)