# models.py
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()

# ════════════════════════════════════════════════
# TABLE 1: USERS
# One table for ALL user types (gigster/host/admin)
# The `role` column controls what they can see/do
# ════════════════════════════════════════════════
class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id            = db.Column(db.Integer, primary_key=True)
    name          = db.Column(db.String(120), nullable=False)
    email         = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role          = db.Column(db.String(20), nullable=False, default='gigster')
    # Gigster-only fields (hosts leave these null)
    dob           = db.Column(db.String(20))
    gender        = db.Column(db.String(20))
    mobile        = db.Column(db.String(20))
    portfolio     = db.Column(db.String(300))
    resume        = db.Column(db.String(300))
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    # Relationships
    gigs_posted   = db.relationship('Gig', backref='host', lazy=True,
                                    foreign_keys='Gig.host_id')
    applications  = db.relationship('Application', backref='gigster', lazy=True,
                                    foreign_keys='Application.gigster_id')

# ════════════════════════════════════════════════
# TABLE 2: GIGS
# Each row = one job posting by a Host
# host_id is a FOREIGN KEY that links to Users table
# ════════════════════════════════════════════════
class Gig(db.Model):
    __tablename__ = 'gigs'
    id            = db.Column(db.Integer, primary_key=True)
    host_id       = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    title         = db.Column(db.String(200), nullable=False)
    description   = db.Column(db.Text, nullable=False)
    location      = db.Column(db.String(200), nullable=False)
    salary        = db.Column(db.String(100), nullable=False)
    experience    = db.Column(db.String(100), nullable=False)
    work_type     = db.Column(db.String(50), default='On-site')
    category      = db.Column(db.String(100), default='General')   # ← ADD THIS
    is_active     = db.Column(db.Boolean, default=True)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    applications  = db.relationship('Application', backref='gig', lazy=True,
                                    cascade='all, delete-orphan')
    category    = db.Column(db.String(100), default='General')

# ════════════════════════════════════════════════
# TABLE 3: APPLICATIONS (The Bridge Table)
# Connects a Gigster ↔ a Gig
# STATUS LIFECYCLE: pending → reviewed → accepted/rejected
# When accepted: contact details are REVEALED (Match Reveal!)
# ════════════════════════════════════════════════
class Application(db.Model):
    __tablename__ = 'applications'
    id            = db.Column(db.Integer, primary_key=True)
    gigster_id    = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    gig_id        = db.Column(db.Integer, db.ForeignKey('gigs.id', ondelete='CASCADE'), nullable=False)
    status        = db.Column(db.String(20), default='pending')
    cover_note    = db.Column(db.Text)
    applied_at    = db.Column(db.DateTime, default=datetime.utcnow)
    # Prevents duplicate applications
    __table_args__ = (db.UniqueConstraint('gigster_id', 'gig_id', name='unique_application'),)
    # In models.py — inside the Gig class, add this line after work_type:
