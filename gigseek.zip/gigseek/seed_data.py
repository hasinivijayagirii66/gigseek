# =============================================================
# seed_data.py — GigSeek Database Seeder
# =============================================================
# HOW TO RUN:
#   1. Make sure app.py has been run at least once (creates DB)
#   2. Run: python seed_data.py
#
# WHAT IT DOES:
#   • Creates 6 sample Host accounts
#   • Creates 25 Gig listings across 15 categories
#   • Safe to re-run — skips duplicates automatically
#
# DEFAULT PASSWORD for all seeded host accounts: host1234
# =============================================================

from app import app, bcrypt
from models import db, User, Gig

# =============================================================
# SEED DATA
# Format per row:
#   (host_email, host_name, title, description,
#    location, salary, experience, work_type, category)
# =============================================================

GIG_SEED_DATA = [

    # ──────────────────────────────────────────────────────
    # 1. ONLINE TUTOR
    # ──────────────────────────────────────────────────────
    (
        "host.edtech@gigseek.com",
        "BrightMinds EdTech",
        "Online Math & Science Tutor",
        "Teach K-12 students Math, Physics, or Chemistry via Zoom. "
        "Flexible hours — you choose your own schedule. Must have strong "
        "subject knowledge and patience with students. All teaching materials "
        "are provided by us. Each session is 45 minutes long. Weekly payout.",
        "Remote",
        "₹400–₹800/session",
        "0-1 years",
        "Remote",
        "Online Tutor"
    ),
    (
        "host.edtech@gigseek.com",
        "BrightMinds EdTech",
        "English Language Tutor (Spoken & Written)",
        "Help students improve their conversational English and writing skills. "
        "Perfect for graduates with good communication. No prior teaching "
        "experience needed — full training and curriculum provided by us. "
        "Work from home, morning or evening slots available.",
        "Remote",
        "₹300–₹600/hour",
        "Fresher",
        "Remote",
        "Online Tutor"
    ),

    # ──────────────────────────────────────────────────────
    # 2. SOCIAL MEDIA MANAGER
    # ──────────────────────────────────────────────────────
    (
        "host.brands@gigseek.com",
        "GrowthLab Agency",
        "Freelance Social Media Manager (Instagram & Facebook)",
        "Manage content calendars, post scheduling, and basic analytics for "
        "3 brand clients. Must know Canva or basic design tools. Deliverable: "
        "15 posts per month per brand. Weekly check-in call with team lead. "
        "Strong written English required.",
        "Remote",
        "₹8,000–₹15,000/month",
        "0-1 years",
        "Remote",
        "Social Media Manager"
    ),
    (
        "host.brands@gigseek.com",
        "GrowthLab Agency",
        "LinkedIn Content Manager for B2B Brand",
        "Create and schedule 20 LinkedIn posts per month for a growing SaaS "
        "startup. Write engaging thought-leadership content, manage comments, "
        "and help grow the follower base. Experience with LinkedIn Analytics "
        "is preferred. Monthly performance review.",
        "Remote",
        "₹6,000–₹10,000/month",
        "0-1 years",
        "Remote",
        "Social Media Manager"
    ),

    # ──────────────────────────────────────────────────────
    # 3. LANGUAGE SUPPORT
    # ──────────────────────────────────────────────────────
    (
        "host.translate@gigseek.com",
        "LinguaBridge Solutions",
        "Hindi–English Translator (Documents)",
        "Translate legal, medical, or business documents from Hindi to English "
        "and vice versa. Flexible gig-based work with payment per page. "
        "Accuracy and turnaround time are critical. NDA required for all "
        "legal document projects. Work assigned project by project.",
        "Remote",
        "₹150–₹300/page",
        "0-1 years",
        "Remote",
        "Language Support"
    ),
    (
        "host.translate@gigseek.com",
        "LinguaBridge Solutions",
        "Multilingual Customer Support Agent (Tamil/Telugu/Kannada)",
        "Handle customer queries via chat and email in regional languages for "
        "a fast-growing e-commerce brand. Shift-based: 4 hours per day, "
        "available in morning or evening slots. Full training is provided. "
        "Freshers welcome — attitude matters more than experience.",
        "Remote",
        "₹12,000–₹18,000/month",
        "Fresher",
        "Remote",
        "Language Support"
    ),

    # ──────────────────────────────────────────────────────
    # 4. VIDEO EDITOR
    # ──────────────────────────────────────────────────────
    (
        "host.media@gigseek.com",
        "PixelCraft Studios",
        "Short-Form Video Editor (Reels & TikTok)",
        "Edit raw footage into engaging 30–90 second social media videos. "
        "Add captions, transitions, background music, and colour grading. "
        "Must know Premiere Pro, CapCut, or DaVinci Resolve. "
        "A portfolio of past edits is required to apply.",
        "Remote",
        "₹500–₹1,500/video",
        "0-1 years",
        "Remote",
        "Video Editor"
    ),
    (
        "host.media@gigseek.com",
        "PixelCraft Studios",
        "Wedding & Event Video Editor",
        "Edit 2–4 hour raw event footage into polished cinematic highlight "
        "reels of 5–10 minutes. Deadline is 7 days per event. Projects are "
        "assigned based on your availability. Cinematic colour grading style "
        "preferred. Previous wedding editing experience is a plus.",
        "Remote",
        "₹3,000–₹6,000/project",
        "1-3 years",
        "Remote",
        "Video Editor"
    ),

    # ──────────────────────────────────────────────────────
    # 5. YOUTUBE / SHORT VIDEO CREATOR
    # ──────────────────────────────────────────────────────
    (
        "host.youtube@gigseek.com",
        "Viral Content Hub",
        "YouTube Script Writer & On-Camera Host",
        "Create and present 2 YouTube videos per week on personal finance "
        "topics. Scripts are provided — you record and deliver the edited "
        "video. Camera, ring light, and basic editing skills required. "
        "Performance bonus for videos crossing 10,000 views.",
        "Remote",
        "₹5,000–₹12,000/month",
        "Fresher",
        "Remote",
        "YouTube / Short Video Creator"
    ),
    (
        "host.youtube@gigseek.com",
        "Viral Content Hub",
        "Instagram Reels Creator — Food & Lifestyle Niche",
        "Shoot and post 3 original Reels per week around food, travel, or "
        "lifestyle topics. You own the account, we co-brand. Revenue share "
        "model plus a fixed monthly base payment. Must have a smartphone "
        "with a good camera. Consistent posting schedule required.",
        "Hybrid",
        "₹4,000 base + revenue share",
        "Fresher",
        "Hybrid",
        "YouTube / Short Video Creator"
    ),

    # ──────────────────────────────────────────────────────
    # 6. CONTENT WRITER
    # ──────────────────────────────────────────────────────
    (
        "host.content@gigseek.com",
        "WordWave Content Co.",
        "SEO Blog Writer (Tech & Startups)",
        "Write 4 SEO-optimised blog posts per month (1,500–2,000 words each) "
        "for B2B tech clients. Topics include AI, SaaS tools, and digital "
        "marketing strategies. Keyword brief and outline provided for each "
        "article. Native-level English writing is required.",
        "Remote",
        "₹1,500–₹3,000/article",
        "0-1 years",
        "Remote",
        "Content Writer"
    ),
    (
        "host.content@gigseek.com",
        "WordWave Content Co.",
        "Product Description Writer — E-Commerce",
        "Write compelling product descriptions for 50–100 SKUs on a fashion "
        "e-commerce platform. One-time project with a 2-week deadline. "
        "Style guide provided. Great for writers who want a quick, "
        "well-paying project without a long-term commitment.",
        "Remote",
        "₹30–₹80/description",
        "Fresher",
        "Remote",
        "Content Writer"
    ),

    # ──────────────────────────────────────────────────────
    # 7. INFLUENCER
    # ──────────────────────────────────────────────────────
    (
        "host.influencer@gigseek.com",
        "NanoReach Marketplace",
        "Nano-Influencer — Health & Wellness Brand (1K–50K followers)",
        "Post 2 sponsored Instagram stories and 1 feed post promoting an "
        "ayurvedic wellness brand. Authentic voice strongly preferred over "
        "scripted content. Product sent to you for free before posting. "
        "Must have an engaged audience in health, fitness, or lifestyle.",
        "Remote",
        "₹2,000–₹8,000/campaign",
        "Fresher",
        "Remote",
        "Influencer"
    ),
    (
        "host.influencer@gigseek.com",
        "NanoReach Marketplace",
        "Campus Brand Ambassador (College Influencer)",
        "Promote an edtech app to your college network via WhatsApp, "
        "Instagram, and word-of-mouth referrals. Commission paid per "
        "verified signup. Fully flexible — work from anywhere on campus. "
        "Best suited for active college students with 500+ followers.",
        "Hybrid",
        "₹50–₹150/referral + bonuses",
        "Fresher",
        "Hybrid",
        "Influencer"
    ),

    # ──────────────────────────────────────────────────────
    # 8. HOME HEALTH AIDE / CAREGIVER
    # ──────────────────────────────────────────────────────
    (
        "host.care@gigseek.com",
        "CareConnect India",
        "Home Health Aide — Post-Surgery Patient Care",
        "Assist elderly or post-surgery patients with daily activities "
        "including medication reminders, basic physiotherapy exercises, "
        "meal preparation, and personal hygiene. Morning shift (7AM–1PM), "
        "6 days per week. Police verification and health certificate required.",
        "Hyderabad, On-site",
        "₹15,000–₹22,000/month",
        "0-1 years",
        "On-site",
        "Home Health Aide / Caregiver"
    ),
    (
        "host.care@gigseek.com",
        "CareConnect India",
        "Night Shift Caregiver for Elderly (Live-In Optional)",
        "Provide overnight care and companionship for an elderly individual "
        "at their private residence. Duties include health monitoring, "
        "emergency response readiness, and light household tasks. "
        "Accommodation and meals provided for the live-in arrangement.",
        "Bangalore, On-site",
        "₹18,000–₹28,000/month",
        "0-1 years",
        "On-site",
        "Home Health Aide / Caregiver"
    ),

    # ──────────────────────────────────────────────────────
    # 9. RETAIL / HOSPITALITY ASSOCIATE
    # ──────────────────────────────────────────────────────
    (
        "host.retail@gigseek.com",
        "QuickStaff Hospitality",
        "Weekend Retail Sales Associate — Fashion Store",
        "Assist walk-in customers, manage display racks, handle billing, "
        "and maintain store cleanliness. Work schedule: Saturday and Sunday, "
        "10AM–8PM. Smart casual dress code required. Incentive bonus paid "
        "on achieving daily sales targets.",
        "Mumbai, On-site",
        "₹700–₹1,000/day",
        "Fresher",
        "On-site",
        "Retail / Hospitality Associate"
    ),
    (
        "host.retail@gigseek.com",
        "QuickStaff Hospitality",
        "Event Banquet Staff — Weddings & Corporate Events",
        "Serve food and beverages, help set up banquet halls, and assist "
        "event coordinators during weddings and corporate functions. "
        "Gig-based work — booked event by event. Formal black uniform "
        "provided. Must be available on most weekends.",
        "Delhi/NCR, On-site",
        "₹800–₹1,200/event",
        "Fresher",
        "On-site",
        "Retail / Hospitality Associate"
    ),

    # ──────────────────────────────────────────────────────
    # 10. COMMISSION-BASED ARTIST
    # ──────────────────────────────────────────────────────
    (
        "host.art@gigseek.com",
        "ArtistryHub Platform",
        "Digital Portrait Artist — Commission Work",
        "Create custom digital portraits of characters, pets, and couples "
        "for clients via our managed platform. You set your own turnaround "
        "time and preferred art style. We handle all client acquisition and "
        "payment processing. Tablet and digital art software required.",
        "Remote",
        "₹500–₹5,000/commission",
        "Fresher",
        "Remote",
        "Commission-Based Artist"
    ),
    (
        "host.art@gigseek.com",
        "ArtistryHub Platform",
        "Freelance Illustrator — Children's Book Project",
        "Illustrate a 24-page children's picture book targeted at ages 3–6. "
        "Preferred style is soft watercolour or clean flat digital art. "
        "Full creative brief, storyboard, and character references provided. "
        "Milestone-based payment schedule. Copyright retained by publisher.",
        "Remote",
        "₹25,000–₹40,000/project",
        "1-3 years",
        "Remote",
        "Commission-Based Artist"
    ),

    # ──────────────────────────────────────────────────────
    # BONUS JOBS — Extra Temporary Gigs
    # ──────────────────────────────────────────────────────
    (
        "host.extra@gigseek.com",
        "FlexWork India",
        "Data Entry Operator (Work From Home)",
        "Enter product data, customer records, or survey results into Excel "
        "or Google Sheets. Daily target of 500 entries with accuracy above "
        "98% required. Weekly payment every Friday. Laptop and stable "
        "internet connection are mandatory for this role.",
        "Remote",
        "₹8,000–₹12,000/month",
        "Fresher",
        "Remote",
        "Data Entry"
    ),
    (
        "host.extra@gigseek.com",
        "FlexWork India",
        "Delivery Partner — Last Mile (Bike Required)",
        "Deliver packages and food orders within a 10km radius of your "
        "chosen zone. Fully flexible hours — pick your own delivery slots "
        "each day. Petrol allowance included in payout. Must own a "
        "two-wheeler and hold a valid driving licence.",
        "Hyderabad, On-site",
        "₹600–₹1,200/day",
        "Fresher",
        "On-site",
        "Delivery Partner"
    ),
    (
        "host.extra@gigseek.com",
        "FlexWork India",
        "Freelance Event Photographer",
        "Photograph corporate events, birthday parties, and product launches. "
        "Deliver a minimum of 100 edited photos within 48 hours of the event. "
        "Must own a DSLR or mirrorless camera. Portfolio required to apply. "
        "Gigs assigned based on your location and availability.",
        "Bangalore, On-site",
        "₹3,000–₹8,000/event",
        "0-1 years",
        "On-site",
        "Photographer"
    ),
    (
        "host.extra@gigseek.com",
        "FlexWork India",
        "Virtual Assistant (Admin & Research Tasks)",
        "Handle email management, calendar scheduling, travel bookings, "
        "and online research tasks for a busy entrepreneur. Commitment of "
        "3–4 hours per day, Monday to Friday. Strong English communication "
        "skills and proficiency in MS Office or Google Workspace required.",
        "Remote",
        "₹10,000–₹16,000/month",
        "0-1 years",
        "Remote",
        "Virtual Assistant"
    ),
    (
        "host.extra@gigseek.com",
        "FlexWork India",
        "Online Yoga & Fitness Instructor",
        "Conduct live online group fitness or yoga sessions of 45 minutes "
        "each via Zoom for our subscriber base. Commitment of 3–5 sessions "
        "per week. Certified trainers are preferred but not mandatory. "
        "We handle all marketing and client acquisition — you just teach.",
        "Remote",
        "₹500–₹1,000/session",
        "0-1 years",
        "Remote",
        "Fitness Instructor"
    ),
]


# =============================================================
# SEED FUNCTION
# =============================================================
def seed():
    with app.app_context():
        print("=" * 55)
        print("  🌱  GigSeek — Database Seeder")
        print("=" * 55)

        hosts_created = 0
        gigs_created  = 0
        skipped       = 0

        for (
            host_email, host_name,
            title, description,
            location, salary,
            experience, work_type,
            category
        ) in GIG_SEED_DATA:

            # ── Step 1: Create host if not exists ─────────
            host = User.query.filter_by(email=host_email).first()
            if not host:
                host = User(
                    name          = host_name,
                    email         = host_email,
                    password_hash = bcrypt.generate_password_hash(
                                        'host1234'
                                    ).decode('utf-8'),
                    role          = 'host'
                )
                db.session.add(host)
                db.session.flush()  # get host.id before commit
                hosts_created += 1
                print(f"\n  ✅ Host created   : {host_email}")

            # ── Step 2: Create gig if not duplicate ───────
            existing = Gig.query.filter_by(
                title   = title,
                host_id = host.id
            ).first()

            if not existing:
                gig = Gig(
                    host_id     = host.id,
                    title       = title,
                    description = description,
                    location    = location,
                    salary      = salary,
                    experience  = experience,
                    work_type   = work_type,
                    category    = category,
                    is_active   = True
                )
                db.session.add(gig)
                gigs_created += 1
                print(f"  📌 Gig added      : {title[:45]}...")
            else:
                skipped += 1

        # ── Step 3: Commit everything at once ─────────────
        db.session.commit()

        # ── Step 4: Print summary ─────────────────────────
        print("\n" + "=" * 55)
        print("  🎉  Seeding Complete!")
        print("=" * 55)
        print(f"  • Hosts created   : {hosts_created}")
        print(f"  • Gigs created    : {gigs_created}")
        print(f"  • Skipped (exist) : {skipped}")
        print(f"  • Total gigs in DB: {Gig.query.count()}")
        print("=" * 55)
        print("  🔑  Host login password : host1234")
        print("  🔑  Admin login         : admin@gigseek.com / admin123")
        print("=" * 55)


# =============================================================
# ENTRY POINT
# =============================================================
if __name__ == '__main__':
    seed()