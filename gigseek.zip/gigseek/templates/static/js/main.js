// =============================================================
// main.js — GigSeek Frontend Interactivity
// =============================================================

// ─── Auto-dismiss Flash Messages ────────────────────────────
// Flash messages fade out automatically after 4 seconds
// This gives a "professional notification" feel
document.addEventListener('DOMContentLoaded', function () {
  const flashes = document.querySelectorAll('.flash-msg');
  flashes.forEach(function (el) {
    // Add fade-out transition
    el.style.transition = 'opacity 0.5s ease';
    // After 4 seconds, fade it out, then remove from DOM
    setTimeout(function () {
      el.style.opacity = '0';
      setTimeout(function () { el.remove(); }, 500);
    }, 4000);
  });
});

// ─── Apply Modal Logic ──────────────────────────────────────
// "Apply Now" button shows a modal instead of a full page reload
// This is better UX — Gigster stays on the feed after applying

function openApplyModal(gigId, gigTitle) {
  // Set the form action URL dynamically based on which gig was clicked
  document.getElementById('apply-form').action = '/apply/' + gigId;
  // Set the modal title
  document.getElementById('modal-gig-title').textContent = gigTitle;
  // Show the modal
  document.getElementById('apply-modal').classList.remove('hidden');
  document.body.style.overflow = 'hidden'; // Prevent background scrolling
}

function closeApplyModal() {
  document.getElementById('apply-modal').classList.add('hidden');
  document.body.style.overflow = '';
}

// Close modal if user clicks the dark background (outside the modal)
document.getElementById('apply-modal')?.addEventListener('click', function (e) {
  if (e.target === this) closeApplyModal();
});

// Close modal with Escape key
document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape') closeApplyModal();
});